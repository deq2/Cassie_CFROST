/*
 * Automatically Generated from Mathematica.
 * Thu 5 Mar 2020 14:53:49 GMT-08:00
 */

#ifndef JS_FFOURBAR_VEC_CASSIE_HH
#define JS_FFOURBAR_VEC_CASSIE_HH

namespace frost {
    namespace gen {
        void Js_ffourBar_vec_cassie(double *p_output1, const double *var1);
    }
}

#endif // JS_FFOURBAR_VEC_CASSIE_HH
