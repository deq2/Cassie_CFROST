/*
 * Automatically Generated from Mathematica.
 * Thu 5 Mar 2020 14:53:03 GMT-08:00
 */

#ifndef FFIXEDKNEESPRING_VEC_CASSIE_HH
#define FFIXEDKNEESPRING_VEC_CASSIE_HH

namespace frost {
    namespace gen {
        void ffixedKneeSpring_vec_cassie(double *p_output1, const double *var1);
    }
}

#endif // FFIXEDKNEESPRING_VEC_CASSIE_HH
