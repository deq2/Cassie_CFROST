/*
 * Automatically Generated from Mathematica.
 * Thu 5 Mar 2020 14:53:01 GMT-08:00
 */

#ifndef J_FRIGHTTOEBOTTOM_VEC_CASSIE_HH
#define J_FRIGHTTOEBOTTOM_VEC_CASSIE_HH

namespace frost {
    namespace gen {
        void J_fRightToeBottom_vec_cassie(double *p_output1, const double *var1);
    }
}

#endif // J_FRIGHTTOEBOTTOM_VEC_CASSIE_HH
