/*
 * Automatically Generated from Mathematica.
 * Thu 5 Mar 2020 14:53:02 GMT-08:00
 */

#ifndef GE_VEC_CASSIE_HH
#define GE_VEC_CASSIE_HH

namespace frost {
    namespace gen {
        void Ge_vec_cassie(double *p_output1, const double *var1);
    }
}

#endif // GE_VEC_CASSIE_HH
