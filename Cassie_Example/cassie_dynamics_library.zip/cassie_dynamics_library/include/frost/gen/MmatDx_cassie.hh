/*
 * Automatically Generated from Mathematica.
 * Thu 5 Mar 2020 14:53:02 GMT-08:00
 */

#ifndef MMATDX_CASSIE_HH
#define MMATDX_CASSIE_HH

namespace frost {
    namespace gen {
        void MmatDx_cassie(double *p_output1, const double *var1);
    }
}

#endif // MMATDX_CASSIE_HH
