/*
 * Automatically Generated from Mathematica.
 * Thu 5 Mar 2020 14:53:49 GMT-08:00
 */

#ifndef J_FFIXEDKNEESPRING_VEC_CASSIE_HH
#define J_FFIXEDKNEESPRING_VEC_CASSIE_HH

namespace frost {
    namespace gen {
        void J_ffixedKneeSpring_vec_cassie(double *p_output1, const double *var1);
    }
}

#endif // J_FFIXEDKNEESPRING_VEC_CASSIE_HH
