/*
 * Automatically Generated from Mathematica.
 * Thu 5 Mar 2020 14:52:14 GMT-08:00
 */

#ifndef FRIGHTTOEBOTTOM_VEC_CASSIE_HH
#define FRIGHTTOEBOTTOM_VEC_CASSIE_HH

namespace frost {
    namespace gen {
        void fRightToeBottom_vec_cassie(double *p_output1, const double *var1);
    }
}

#endif // FRIGHTTOEBOTTOM_VEC_CASSIE_HH
